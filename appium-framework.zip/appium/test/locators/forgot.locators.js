// Locators for the forgot-password screen.

export const forgot = {
  heading: 'h1',
  emailInput: '#forgot-email',
  emailError: '#forgot-err',
  resetButton: '#reset-button',
  status: '#reset-status',
  backToLoginLink: '#back-link',
};
