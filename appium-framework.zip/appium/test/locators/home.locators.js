// Locators for the home screen shown after a successful login.

export const home = {
  heading: 'h1',
  logOutLink: 'a[href="/login"]',
};
