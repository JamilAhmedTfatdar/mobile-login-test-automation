import BasePage from './BasePage.js';
import { forgot as F } from '../locators/forgot.locators.js';

class ForgotPasswordPage extends BasePage {
  constructor() {
    super('/forgot');
  }

  get heading() { return $(F.heading); }
  get emailInput() { return $(F.emailInput); }
  get emailError() { return $(F.emailError); }
  get resetButton() { return $(F.resetButton); }
  get status() { return $(F.status); }
  get backToLoginLink() { return $(F.backToLoginLink); }

  async resetPasswordFor(email) {
    await this.emailInput.setValue(email);
    await this.resetButton.click();
  }

  async tapBackToLogin() {
    await this.backToLoginLink.click();
  }

  async waitUntilLoaded() {
    await this.waitForUrlToContain('/forgot');
  }
}

export default new ForgotPasswordPage();
